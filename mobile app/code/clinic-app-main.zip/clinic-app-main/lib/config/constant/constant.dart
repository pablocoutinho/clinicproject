var cliicItems = [
  'Select your Clinic',
  'STC Clinic',
  'HIV Clinic',
  'Infectious Diseases Clinic',
];
